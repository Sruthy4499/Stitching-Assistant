<?php
session_start();
include 'connection.php';
if ((!isset($_SESSION['user'])))
{
header('location:user_index.html');
       
}
$lid=$_SESSION['user'];


if(isset($_POST['update']))
{  
$fname=$_POST['fname'];
$age=$_POST['age'];
$address=$_POST['address'];
$email=$_POST['email'];
$phonenumber=$_POST['phonenumber'];
$image=$_POST['image'];




$sql2=mysqli_query($con,"UPDATE  `register` SET `fname`='$fname',`age`='$age',`address`='$address','email'='$email',`phonenumber`='$phonenumber',`image`='$image'where`rid`='$lid'") or die(mysqli_error($con));
echo"<script>alert('Profile updated successfully');</script>";
}

$sql=mysqli_query($con,"SELECT * FROM  'register' JOIN  'login' ON register.rid=login.loginid where login.loginid=$lid ");
                $count=0;
                while($row=mysqli_fetch_assocl($sql))
                { 
                    $count++;
                }
                
            ?>
<!Doctype html>
<html>
<title>
    User Profile
</title>

<head>
<style>
    .cen{
  position: absolute;
  margin: 35px;
  top: 40%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 400px;
  height: 400px;
  background: white;
  border-radius: 10px;
  box-shadow: 10px 10px 20px rgba(0,0,0,0.05);
 
}
    </style>


</head>



<body background="img/imag.png">
<div class="cen">
     
            <form id="myform" action="" method="post">
       
                <div class="txt_field">
                 
                   

                    <center>
                        <table>
               <br>
                       
                   <label><u><b>USER-DETAILS</b></u></label><br><br>
                            <tr>
   
                                <td>First Name : </td>
                                <td><input type="text"  name="fname" value="<?php echo $row['1'] ; ?>" maxlength="50" required=""> </td>
                            </tr><br>
                            <tr>
                                <td>Age : </td>
                                <td> <input type="text" name="age" value="<?php echo $row['2']; ?>" maxlength="50" required=""></td>
                            </tr>
                            <tr>
                                <td> Address :</td>
                                <td> <input type="text" name="address" value="<?php echo $row['3']; ?>" maxlength="50" required=""></td>
                            </tr>
                            <tr>
                                <td> Email :</td>
                                <td><input type="text" name="email" value="<?php echo $row['4']; ?>" maxlength="30" required=""> </td>
                            </tr>
                            <tr>
                                <td> Phone Number :</td>
                                <td> <input type="text" name="phonenumber" value="<?php echo$row['5']; ?>" maxlength="30" required="" ></td>
                            </tr>
                            <tr>
                                <td> Image:</td>
                                <td> <input type="text" name="image" value="<?php echo$row['6']; ?>" maxlength="12" required=""></td>
                            </tr>
        
                           
                            <tr>
                       
                                <td colspan="2">
                                    <center>
                   <br><br>
                   <input type="submit" name="update" value="Update"/>
                   
                     </form></center>
                                </td>
                            </tr>
                           
                 
                   

                    </table>
            </form>
            </div>
        </div>
    </body>

</html>
 



