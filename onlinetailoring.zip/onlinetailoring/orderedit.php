<?php      
    include 'connection.php';
    $order_id=$_GET['order_id'];
    $sql="select *from `order` where  order_id='$order_id'";
    $result=mysqli_query($con,$sql);
   $row=mysqli_fetch_assoc($result);
    $username=$row['username'];
    $product_name = $row['product_name'];
    $fabric = $row['fabric'];
    $description = $row['description'];
    $datereceived = $row['daterecived'];
    $datecolleted = $row['datecollected'];
    

    if(isset($_POST['s']))
    {
    $order_id=$_GET['order_id']; 
    $username = $_POST['username'];
    $product_name = $_POST['product_name'];
    $fabric = $_POST['fabric'];
    $description = $_POST['description'];
    $datereceived= $_POST['datereceived'];
    $datecollected= $_POST['datecollected'];
    
    
   
        mysqli_query($con,"UPDATE `order` SET 
        'order_id`='$order_id','username'='$username',`product_name`='$product_name',`fabric`='$fabric',`description`='$description',`datereceived`='$datereceived','datecollected'='$datecollected' where order_id='$order_id'");
    
            echo "<script>alert('Updated');</script>";
            header('location: order.php');
     }
  
      
    
 ?>
 
 <!DOCTYPE html>  
<html>  
<head>  
<meta name="viewport" content="width=device-width, initial-scale=1">  
<style>  
body{  
  font-family: Calibri, Helvetica, sans-serif;  
  background-color: green;  
}  
.container {  
    padding: 50px;  
  background-color: white;  
}  
  
input[type=text], input[type=password], textarea {  
  width: 100%;  
  padding: 15px;  
  margin: 5px 0 22px 0;  
  display: inline-block;  
  border: none;  
  background: #f1f1f1;  
}  
input[type=text]:focus, input[type=password]:focus {  
  background-color: orange;  
  outline: none;  
}  
 div {  
            padding: 10px 0;  
         }  
hr {  
  border: 1px solid #f1f1f1;  
  margin-bottom: 25px;  
}  
.registerbtn {  
  background-color: #4CAF50;  
  color: white;  
  padding: 16px 20px;  
  margin: 8px 0;  
  border: none;  
  cursor: pointer;  
  width: 100%;  
  opacity: 0.9;  
}  
.registerbtn:hover {  
  opacity: 1;  
}  
</style> 
<style> form{
  padding: 150px 170px;
}</style> 
</head>  
<body>  
<form method='post' action="" >  
  
  <div class="container">  
  <center>  <h1>update </h1> </center>  
  <hr>  
  <div class="modal-header">
 
                          </div>
                      <div class="modal-body">
                     <div class="card-body card-block">
                     <div class="form-group">
                        <label for="company" class=" form-control-label">username</label>
                   <input type="text"   class="form-control" name="username"  id="username"  onfocusout="f1()" value=<?php echo $username?>>
                </div>
                <div class="form-group">
                        <label for="company" class=" form-control-label">product_name </label>
                    <input type="text"  class="form-control" name="product_name" id="product_name"  onfocusout="f1()" value=<?php echo $product_name?>>
                </div>
                <div class="form-group">
                        <label for="company" class=" form-control-label">fabric </label>
                    <input type="text"  class="form-control" name="fabric" id="fabric"  onfocusout="f1()" value=<?php echo $fabric?>>
                </div>
                <div class="form-group">
                        <label for="company" class=" form-control-label">Description</label>
                    <input type="text"  class="form-control" name="description"  id="description"  onfocusout="f1()" value=<?php echo $description?>>
                </div>
                <div class="form-group">
                        <label for="company" class=" form-control-label">datereceived</label>
                    <input type="text"  class="form-control" name="datereceived" id="daterecived" onfocusout="f1()" value=<?php echo $datereceived?>>
                </div>
                <div class="form-group">
                        <label for="company" class=" form-control-label">datecollected</label>
                    <input type="text"  class="form-control" name="datecollected" id="datecollected" onfocusout="f1()" value=<?php echo $datecollected?>>
                </div>
                
                
               
               
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal" style="margin-right: 66%">Cancel</button>
                    <button type="submit" class="btn btn-primary" name="s">Update</button>
            </div>
                   
            </div>
                </div>
            
</form>  
</body>  
</html>