<?php
include 'connection.php';
session_start();

if(isset($_POST['submit'])){
  $username=$_POST['username'];
  $password=$_POST['password'];

  $sql="SELECT * FROM login where username ='$username' AND password = '$password'";
  $result =mysqli_query($con,$sql);
  if($result){
    if($row=mysqli_fetch_array($result)){
  if($row[3]=="admin"){
    ?>
  <script type="text/Javascript">  
    window.location.href="admin_index.php";
   </script>
   <?php     
  }else if($row[3]=="user"){
    $_SESSION['user']=$row['loginid'];
    
    
    ?>
  <script type="text/Javascript">  
    window.location.href="user_index.php";
   </script> 
   
    <?php
  }
  else
{
  echo"Invalid Username and Password";
  
}
}
  }
}


?>




<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Login Form </title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
<link rel="stylesheet" type="text/css" href="login.css">
</head>
<body>
<div id="login-form-wrap">
  <h2>Login</h2>
  <form id="login-form" method="post" action="">
    <p>
    <input type="text" id="username" name="username" placeholder="Username" required><i class="validation"><span></span><span></span></i>
    </p>
    <p>
    <input type="password" id="password" name="password" placeholder="password" required><i class="validation"><span></span><span></span></i>
    </p>
    <p>
    <input type="submit" id="login" name="submit" value="Login">
    </p>
  </form>
  <div id="create-account-wrap">
    <p>Not a member? <a href="register.php">Create Account</a><p>
  </div>
</div>
  
</body>
</html>