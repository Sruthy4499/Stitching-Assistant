<?php
include 'connection.php';
if(isset($_POST['submit']))
{  
$fname=$_POST['fname'];
$age=$_POST['age'];
$address=$_POST['address'];
$email=$_POST['email'];
$phonenumber=$_POST['phonenumber'];
$image=$_POST['image'];




$sql=mysqli_query($con,"UPDATE' login' SET 'username'='$username','password'='$password'WHERE loginid='$loginid'");
$sql2=mysqli_query($con,"UPDATE 'register' SET 'fname'='$fname','age'='$age','address'='$addresss','email'=$email,'phonenumber'='$phonenumber','image'=$image);


header("location:userprofile.php");

}


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>RTO - User Registeration</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free Website Template" name="keywords">
    <meta content="Free Website Template" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
   
    <!-- CSS Libraries -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="lib/flaticon/font/flaticon.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style1.css" rel="stylesheet">
    
</head>

<body>
 
   
            <div class="update">
                   
                    <form method="post" action="#" onsubmit="return validate()">
                      <div class="txt_field">
                        <input type="text"  name="fname" value="" maxlength="50" required="">
                        <span></span>
                        <label>First Name</label>
                      </div>
                      <div class="txt_field">
                        <input type="text" name="age" value="" maxlength="50" required="">
                        <span></span>
                        <label>Age</label>
                      </div>
                      <div class="txt_field">
                        <input type="text" name="addresss" value="" maxlength="50" required="">
                        <span></span>
                        <label>Address</label>
                      </div>
                      <div class="txt_field">
                        <input type="text" name="email" value="" maxlength="30" required="">
                        <span></span>
                        <label>Email</label>
                      </div>                    
                      <div class="txt_field">
                        <input type="text" name="phonenumber" value="" maxlength="30" required="" >
                        <span></span>
                        <label>Phonenumber</label>
                      </div>
                      <div class="txt_field">
                        <input type="text" name="image" value="" maxlength="30" required="">
                        <span></span>
                        <label>image</label>
                      </div>  
                  
                      <input type="submit" name="submit" value="Update">    
            </div>
           


        </form>
   
</body>