<?php
include_once("connection.php");


$result = mysqli_query($con, "SELECT * FROM order ORDER BY order_id DESC"); 
?>

<html>
<head>  
    <title>Homepage</title>
</head>
<style>
    body{
      background-image: url("img/imag.png");
      background-attachment: fixed;
      background-position: center;
      background-repeat: no-repeat;
      background-size: cover;
     
    }
  </style>
<body>
    <a href="orderadd.php">Add New Order</a><br/><br/>

    <table width='80%' border=0>
        <tr bgcolor='#CCCCCC'>
            <td>username</td>
            <td>productname</td>
            <td>fabric</td>
            <td>descriptiion</td>
            <td>datereceived</td>
            <td>datecollected</td>
        </tr>
        <?php 
        
        while($res = mysqli_fetch_array($result)) {         
            echo "<tr>";
            echo "<td>".$res['username']."</td>";
            echo "<td>".$res['product_name']."</td>";
            echo "<td>".$res['fabric']."</td>"; 
            echo "<td>".$res['description']."</td>";
            echo "<td>".$res['datereceived']."</td>";
            echo "<td>".$res['datecollected']."</td>";
            
            echo "<td><a href=\"orderedit.php?id=$res[order_id]\">Edit</a> | <a href=\"orderdelete.php?id=$res[order_id]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";       
        }
        ?>
    </table>
</body>
</html>