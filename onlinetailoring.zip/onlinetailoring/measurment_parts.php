<?php
include_once("connection.php");
$result = mysqli_query($con, "SELECT * FROM part ORDER BY id DESC"); 
?>

<html>
<head>  
    <title>Homepage</title>
</head>
<style>
    body{
      background-image: url("img/imag.png");
      background-attachment: fixed;
      background-position: center;
      background-repeat: no-repeat;
      background-size: cover;
     
    }
  </style>
<body>
    <a href="partadd.php">Add New Part</a><br/><br/>

    <table width='80%' border=0>
        <tr bgcolor='#CCCCCC'>
            <td>Title</td>
            <td>Type</td>
            <td>Descriptions</td>
            <td>Image</td>
        </tr>
        <?php 
        while($res = mysql_fetch_array($result)) { // mysql_fetch_array is deprecated, we need to use mysqli_fetch_array 
        //while($res = mysqli_fetch_array($result)) {         
            echo "<tr>";
            echo "<td>".$res['title']."</td>";
            echo "<td>".$res['type']."</td>";
            echo "<td>".$res['description']."</td>"; 
            echo "<td>".$res['image']."</td>";
            echo "<td><a href=\"partedit.php?part_id=$res[part_id]\">Edit</a> | <a href=\"partdelete.php?part_id=$res[part_id]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";       
        }
        ?>
    </table>
</body>
</html>