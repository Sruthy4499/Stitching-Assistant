<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Vismaya</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="Free Website Template" name="keywords">
        <meta content="Free Website Template" name="description">

        <!-- Favicon -->
        <link href="img/favicon.ico" rel="icon">

        <!-- Google Font -->
        <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700;800;900&display=swap" rel="stylesheet"> 
        
        <!-- CSS Libraries -->
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
        <link href="lib/flaticon/font/flaticon.css" rel="stylesheet">
        <link href="lib/animate/animate.min.css" rel="stylesheet">
        <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

        <!-- Template Stylesheet -->
        <link href="css/style.css" rel="stylesheet">
    </head>

    <body>
        <!-- Top Bar Start -->
        <div class="top-bar">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-4 col-md-12">
                        <div class="logo">
                            <a href="index.html">
                                <img src="img/vismaya.png" alt="Logo"> 
                            </a>
                        </div>
                    </div>
                            <div class="col-4">
                                <div class="top-bar-item">
                                    <div class="top-bar-icon">
                                        <i class="fa fa-phone-alt"></i>
                                    </div>
                                    <div class="top-bar-text">
                                        <h3>Call Us</h3>
                                        <p>+7306310207</p>
                                    </div>
                                </div>
                            </div>
                      </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Top Bar End -->

        <!-- Nav Bar Start -->
        <div class="nav-bar">
            <div class="container">
                <nav class="navbar navbar-expand-lg bg-dark navbar-dark">
                    <a href="#" class="navbar-brand">MENU</a>
                    <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                        <div class="navbar-nav mr-auto">
                           <a href="admin_index.php" class="nav-item nav-link active">Home</a>
                            <a href="addorder.php" class="nav-item nav-link">Add Order</a>
                            <a href="addmeasurment.php" class="nav-item nav-link">Add Measurment</a> 
                            <a href="logout.php" class="nav-item nav-link">Logout</a>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
        <!-- Nav Bar End -->
        <?php
require_once "connection.php";
if(isset($_POST['submit'])){
    
    $username= $_POST['username'];
    $product_name=$_POST['product_name'];
    $fabric=$_POST['fabric'];
    $description= $_POST['description'];
    $datereceived=$_POST['datereceived'];
    $datecollected=$_POST['datecollected'];
    

    $sql = "INSERT INTO order(username,product_name,fabric,description,datereceived,datecollected) VALUES('$username','$product_name','$fabric','$description','$datereceived','$datecollected')";
    $result = mysqli_query($con, $sql);
   

    if($result){
        echo "<script>";
            echo 'alert("Inserted Successfully")';
        echo "</script>";
    }else{
        echo "<script>";
            echo 'alert("Failed to insert")';
        echo "</script>";
    }

}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Insert order</title>
    <link rel="stylesheet" href="./css/style.css">
</head>
<style>
    body{
      background-image: url("img/pic3.jpg");
      background-attachment: fixed;
      background-position: center;
      background-repeat: no-repeat;
      background-size: cover;
     
    }
  </style>
<body>
   
    

    <section>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-9">
                <h4 class="head-tag">Insert order</h4>
                    <div class="container">
                        <div class="row">
                            <div class="col-1"></div>
                            <div class="col-10 panelBack">
                                <form action="order.php" method="POST" enctype="multipart/form-data"><br><Br>
                                <input type="text" name="username" class="input-txt" placeholder="Enter Name"><br><br>
                                <input type="text" name="product_name" class="input-txt" placeholder="Enter product Name"><br><br>
                                <input type="text" name="fabric" class="input-txt" placeholder="Enter fabric"><br><br> 
                                <input type="text" name="description" class="input-txt" placeholder="Enter description"><br><br>
                                    <input type="text" name="daterecived" class="input-txt" placeholder="Enter daterecived"><br><br>
                                    <input type="file" name="datecollected" class="input-txt" placeholder="Enter datacollected"><br><br>
                                
                                    
                                    <input type="submit" name="submit" value="Insert" class="btn btn-primary" style="margin-left: 70%;">
                                </form>
                            </div>
                            <div class="col-1"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

</body>
</html>

