<?php      
    include 'connection.php';
    $sql="select * from part";
    $result=mysqli_query($con,$sql);
   $row=mysqli_fetch_assoc($result);
    $title=$row['title'];
    $type = $row['type'];
    $description = $row['description'];
    $image = $row['image'];
    

    if(isset($_POST['s']))
    {
    $part_id=$_GET['part_id']; 
    $title = $_POST['title'];
    $type = $_POST['type'];
    $description = $_POST['description'];
    $image = $_POST['image'];
    
   
        mysqli_query($con,"UPDATE `part` SET 
        'part_id`='$part_id',`title`='$title',`type`='$type',`description`='$description',`image`='$image' where part_id='$part_id'");
    
            echo "<script>alert('Updated');</script>";
            header('location: measurment_parts.php');
     }
  
      
    
 ?>
 
 <!DOCTYPE html>  
<html>  
<head>  
<meta name="viewport" content="width=device-width, initial-scale=1">  
<style>  
body{  
  font-family: Calibri, Helvetica, sans-serif;  
  background-color: pink;  
}  
.container {  
    padding: 50px;  
  background-color: white;  
}  
  
input[type=text], input[type=password], textarea {  
  width: 100%;  
  padding: 15px;  
  margin: 5px 0 22px 0;  
  display: inline-block;  
  border: none;  
  background: #f1f1f1;  
}  
input[type=text]:focus, input[type=password]:focus {  
  background-color: orange;  
  outline: none;  
}  
 div {  
            padding: 10px 0;  
         }  
hr {  
  border: 1px solid #f1f1f1;  
  margin-bottom: 25px;  
}  
.registerbtn {  
  background-color: #4CAF50;  
  color: white;  
  padding: 16px 20px;  
  margin: 8px 0;  
  border: none;  
  cursor: pointer;  
  width: 100%;  
  opacity: 0.9;  
}  
.registerbtn:hover {  
  opacity: 1;  
}  
</style> 
<style> form{
  padding: 150px 170px;
}</style> 
</head>  
<body>  
<form method='post' action="" >  
  
  <div class="container">  
  <center>  <h1>update </h1> </center>  
  <hr>  
  <div class="modal-header">
 
                          </div>
                      <div class="modal-body">
                     <div class="card-body card-block">
                     <div class="form-group">
                        <label for="company" class=" form-control-label">Title:</label>
                   <input type="text"   class="form-control" name="title"  id="title"  onfocusout="f1()" value=<?php echo $title?>>
                </div>
                <div class="form-group">
                        <label for="company" class=" form-control-label">Type </label>
                    <input type="text"  class="form-control" name="type" id="type"  onfocusout="f1()" value=<?php echo $type?>>
                </div>
                <div class="form-group">
                        <label for="company" class=" form-control-label">Description</label>
                    <input type="text"  class="form-control" name="description"  id="description"  onfocusout="f1()" value=<?php echo $description?>>
                </div>
                <div class="form-group">
                        <label for="company" class=" form-control-label">image</label>
                    <input type="file"  class="form-control" name="label" id="image" onfocusout="f1()" value=<?php echo $image?>>
                </div>
                
                
               
               
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal" style="margin-right: 66%">Cancel</button>
                    <button type="submit" class="btn btn-primary" name="s">Update</button>
            </div>
                   
            </div>
                </div>
            
</form>  
</body>  
</html>