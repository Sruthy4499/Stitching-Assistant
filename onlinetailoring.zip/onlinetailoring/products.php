<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>VISMAYA</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="Free Website Template" name="keywords">
        <meta content="Free Website Template" name="description">

        <!-- Favicon -->
        <link href="img/favicon.ico" rel="icon">

        <!-- Google Font -->
        <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700;800;900&display=swap" rel="stylesheet"> 
        
        <!-- CSS Libraries -->
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
        <link href="lib/flaticon/font/flaticon.css" rel="stylesheet">
        <link href="lib/animate/animate.min.css" rel="stylesheet">
        <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

        <!-- Template Stylesheet -->
        <link href="css/style.css" rel="stylesheet">
    </head>

    <body>
        <!-- Top Bar Start -->
        <div class="top-bar">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-4 col-md-12">
                        <div class="logo">
                            <a href="index.html">
                                <h1>VIS<span>MAYA</span></h1>
                                <img src="img/vismaya.png" alt="Logo"> 
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-8 col-md-7 d-none d-lg-block">
                        <div class="row">
                            <div class="col-4">
                                <div class="top-bar-item">
                                    <div class="top-bar-icon">
                                        <i class="fa fa-phone-alt"></i>
                                    </div>
                                    <div class="top-bar-text">
                                        <h3>Call Us</h3>
                                        <p>+91 7306310207</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="top-bar-item">
                                    <div class="top-bar-icon">
                                        <i class="far fa-envelope"></i>
                                    </div>
                                    <div class="top-bar-text">
                                        <h3>Email Us</h3>
                                        <p>vismaya@gmail.com</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Top Bar End -->

        <!-- Nav Bar Start -->
        <div class="nav-bar">
            <div class="container">
                <nav class="navbar navbar-expand-lg bg-dark navbar-dark">
                    <a href="#" class="navbar-brand">MENU</a>
                    <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                        <div class="navbar-nav mr-auto">
                            <a href="index.php" class="nav-item nav-link">Home</a>
                            <a href="about.php" class="nav-item nav-link active">About</a>
                            <a href="services.php" class="nav-item nav-link">Service</a>
                            <a href="orders.php" class="nav-item nav-link">Orders</a>
                            <a href="contact.php" class="nav-item nav-link">Contact</a>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
        <!-- Nav Bar End -->
        
        
        <!-- Page Header Start -->
        <div class="page-header">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <h2>Products</h2>
                    </div>
                    <div class="col-12">
                        <a href="">Home</a>
                        <a href="">Products</a>
                    </div>
                </div>
            </div>
        </div>
        <!-- Page Header End -->

          <!-- product start-->
	<div id="products" class="layout_padding product_section ">
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<h1 class="product_text"><strong><span class="den">Vismaya</span>Products</strong></h1>
				</div>
			</div>
		    <div class="product_section_2 images">
			    <div class="row">
			    	<div class="col-sm-4">
			    		<div class="images"><img src="img/kurti.jpg" style="max-width: 100%; width: 100%;"></div>
			    		<h2 class="den_text croissants"><a href="style.php">kurti</a></h2>
			    	</div>
			    	<div class="col-sm-4">
			    		<div class="images"><img src="img/gown.png" style="max-width: 100%; width: 100%;"></div>
			    		<h2 class="den_text"><a href="style.php">Gown</a></h2>
			    	</div>
			    	<div class="col-sm-4">
			    		<div class="images"><img src="img/kids.png" style="max-width: 100%; width: 100%;"></div>
			    		<h2 class="den_text"><a href="style.php">Kids</a></h2>
                    </div>
			    	<div class="col-sm-4">
			    		<div class="images"><img src="img/blouse1.png" style="max-width: 100%; width: 100%;"></div>
			    		<h2 class="den_text"><a href="style.php">Blouse</a></h2>
			    	</div>
			    	<div class="col-sm-4">
			    		<div class="images"><img src="img/wedding.png" style="max-width: 100%; width: 100%;"></div>
			    		<h2 class="den_text"><a href="style.php">Wedding Dress</a></h2>
			    	</div>
			    	<div class="col-sm-4">
			    		<div class="images"><img src="img/bottom.png" style="max-width: 100%; width: 100%;"></div>
			    		<h2 class="den_text"><a href="style.php">Bottom</a></h2>
			    	</div>
			    </div>
		    </div>
		</div>
	</div>
	<!-- product end-->

           
        
                    

        <!-- Footer Start -->
        <div class="footer">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-contact">
                            <h2>Get In Touch</h2>
                            <p><i class="fa fa-map-marker-alt"></i>Vismaya Street, KOTTAYAM, KERALA</p>
                            <p><i class="fa fa-phone-alt"></i>+91 7306310207</p>
                            <p><i class="fa fa-envelope"></i>vismaya@gmail.com</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-link">
                            <h2>Popular Links</h2>
                            <a href="">About Us</a>
                            <a href="">Contact Us</a>
                            <a href="">Our Service</a>
                            <a href="">Designers Points</a>
                            <a href="">Pricing Plan</a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-link">
                            <h2>Useful Links</h2>
                            <a href="">Terms of use</a>
                            <a href="">Privacy policy</a>
                            <a href="">Cookies</a>
                            <a href="">Help</a>
                            <a href="">FQAs</a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-newsletter">
                            <h2>Newsletter</h2>
                            <form>
                                <input class="form-control" placeholder="Full Name">
                                <input class="form-control" placeholder="Email">
                                <button class="btn btn-custom">Submit</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container copyright">
                <p>&copy; <a href="#">Your Site Name</a>, All Right Reserved. Designed By <a href="https://htmlcodex.com">HTML Codex</a></p>
            </div>
        </div>
        <!-- Footer End -->
        
        <!-- Back to top button -->
        <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
        
        <!-- Pre Loader -->
        <div id="loader" class="show">
            <div class="loader"></div>
        </div>

        <!-- JavaScript Libraries -->
        <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
        <script src="lib/easing/easing.min.js"></script>
        <script src="lib/owlcarousel/owl.carousel.min.js"></script>
        <script src="lib/waypoints/waypoints.min.js"></script>
        <script src="lib/counterup/counterup.min.js"></script>
        
        <!-- Contact Javascript File -->
        <script src="mail/jqBootstrapValidation.min.js"></script>
        <script src="mail/contact.js"></script>

        <!-- Template Javascript -->
        <script src="js/main.js"></script>
    </body>
</html>