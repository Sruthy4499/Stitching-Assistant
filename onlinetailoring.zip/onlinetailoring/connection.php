<?php
$hostname="localhost"; //local server name default localhost
$username="root";  //mysql username default is root.
$password="";       //blank if no password is set for mysql.
$database="vismaya1";  //database name which you created
$con=mysqli_connect('localhost','root','','vismaya1') or die("error");
?>

