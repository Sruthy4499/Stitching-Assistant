<?php
include 'connection.php';
if(isset($_POST['submit'])){
  $fname=$_POST['fname'];
  $age=$_POST['age'];
  $address=$_POST['address'];
  $email=$_POST['email'];
  $phonenumber=$_POST['phonenumber'];
  $image=$_POST['image'];
  $username=$_POST['username'];
  $password=$_POST['password'];
  $sq=mysqli_query($con,"INSERT INTO 'login'('username','password','usertype')values('$username','$password', 0)");
  $loginid=mysqli_insert_id($con);
  $sql=mysqli_query($con,"INSERT INTO `register`(`loginid`, `fname`, `age`, `address`, `email`, `phonenumber`, `image`) VALUES('$loginid','$fname','$age','$address','$email','$phonenumber','$image')");
  header('Location: login.php');
}
  
?>


<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Page</title>
    <style>
        body 
    {
        margin:0;
      padding:0;
      background:url("img/imag.png");
      -webkit-background-size:cover;
      background-size:cover;
      background-position:center;
      font-family:sans-serif;
       
        }
       
        .body-content {
            padding-top: 10vh;
        }
       
        .container {
            width: 400px;
            height: 520px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            margin: auto;
            border: 0px;
            border-radius: 15px;
            background:white;
      box-shadow:8px 8px 50px #000;
      
        }
       
        .logo {
            margin-bottom: 0px;
            margin-top: 0px;
            padding-top: 0;
        }
       
        .logo img {
            width: 100px;
            margin: 10px;
            border-radius: 10px;
        }
       
        .form {
            display: flex;
            flex-direction: column;
        }
       
        .form-item {
            margin: 5px;
            padding-bottom: 10px;
            display: flex;
        }
       
        .form-item label {
            display: block;
            padding: 2px;
            font-size: 20px;
            width: 100px;
        }
       
        .form-item input {
            width: 320px;
            height: 35px;
            border: 2px solid #e1dede69;
            border-radius: 20px;
            background:#e1dede69;
            
        }
       
        .form-btns {
            display: flex;
            flex-direction: column;
            margin: auto;
            padding: 10px 0;
      
        }
       
        .form-btns button {
            margin: auto;
            font-size: 20px;
            padding: 5px 15px;
            border: 2px solid;
            border-radius: 15px;
            background:black;
            width: 280px;
            cursor: pointer;
      color:white;
        }
    
    .form-btns button:hover
    {
      cursor: pointer;
      background:#b0b435;
      color:#000;
    }
       
        .options {
            padding-top: 15px;
            margin: auto;
        }
       
        .options a {
            text-decoration: none;
            color: black;
            margin: 0 40px;
            font-family: Arial, Helvetica, sans-serif;
            font-size: 20px;

        }
        .options a:hover {
            color: black;
 
        }
       
        p {
            text-align: center;
            font-size: 10px;
            font-family: Arial, Helvetica, sans-serif;
        }
    </style>

<script>
  function registration()
      {
  
          var fname= document.getElementById("t1").value;
          var age= document.getElementById("t2").value;
          var address= document.getElementById("t3").value;
          var email= document.getElementById("t4").value;
          var phonenumber= document.getElementById("t5").value;
          var username= document.getElementById("t6").value;
          var password= document.getElementById("t7").value;     
          var cpwd= document.getElementById("t8").value
          var image= document.getElementById("t9").value;
          
         
          var password_expression = /^(?=.?[A-Z])(?=.?[a-z])(?=.?[0-9])(?=.?[#?!@$%^&*-])/;
          var letters = /^[A-Za-z]+$/;
          var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
          var phonenumber = /^\d{10}$/;
          var image= /^(\.jpg|\jpeg|\.png|\.gif)$/i;
      if(fname=='')
           {
              alert('Please enter your name');
          }
          else if(!letters.test(fname))
          {
              alert('Name field required only alphabet characters');
          }
          else if(age=='')
          {
              alert('Please enter your user age');
          }
          else if (!age.test(age))
          {
              alert('Enter the age format correctly');
          }
          else if(address=='')
          {
              alert('Please enter your user address');
          }
          else if (!letters.test(address))
          {
              alert('Enter the address format correctly');
          }
     
          else if(email=='')
          {
              alert('Please enter your user email id');
          }
          else if (!filter.test(email))
          {
              alert('Enter the e-mail format correctly');
          }
      else if(phonenumber=='')
          {
              alert('Please enter your number');
          }
      else if(!phonenumber.test(number))
          {
              alert('Enter number correctly');
          }
          else if(image=='')
         {
    alert('please upload photo');
         }
      else if(!image.test(file))
         {
  alert('Invalid data');
         }
          else if(username=='')
          {
              alert('Please enter the user name.');
          }
          else if(!letters.test(username))
          {
              alert('User name field required only alphabet characters');
          }
          else if(password=='')
          {
              alert('Please enter Password');
          }
          else if(cpwd=='')
          {
              alert('Enter Confirm Password');
          }
          else if(!password_expression.test(password))
          {
              alert ('Upper case, Lower case, Special character and Numeric letter are required in Password filed');
          }
          else if(password != cpwd)
          {
              alert ('Password not Matched');
          }
          else if(document.getElementById("t5").value.length < 6)
          {
              alert ('Password minimum length is 6');
          }
          else if(document.getElementById("t5").value.length > 12)
          {
              alert ('Password max length is 12');
          }
          else
          {                                   
                 alert('Successfully Registered');
               
          }
      }
      </script>

</head>

<body>
    <div class="body-content">

        <div class="container">
            <div class="logo">
                <img src="img\vismaya.png" alt="vismaya logo" srcset="">
            </div>
            <div class="login-form">
                <form action="" method="POST">
        <div class="form-item">
                        <input type="text" name="fname" id="t1" placeholder="Enter your name">
                    </div>
                                <div class="form-item">
                        <input type="text" name="age" id="t2" placeholder="Enter your age">
                    </div>
                                 <div class="form-item">
                        <input type="text" name="address" id="t3" placeholder="Enter your address">
                    </div>
          <div class="form-item">
                        <input type="text" name="email" id="t4" placeholder="Enter your e-mail">
                    </div>
          <div class="form-item">
                        <input type="number" name="phonenumber" id="t5" placeholder="Enter your Phone number">
                    </div>
                    <div class="form-item">
                       
                        <input type="text" name="username" id="t6" placeholder="Enter your Username">
                    </div>
                    <div class="form-item">
                       
                        <input type="password" name="password" id="t7" placeholder="Enter Password">
                    </div>
          <div class="form-item">
                        <input type="password" name="cpwd" id="t8" placeholder="Confirm Password">
                    </div>

          <div class="form-item">
                        <input type="file" name="image" id="t9" placeholder="Upload image">
                    </div>
                    <div class="form-btns">

                        <button type="submit" name="submit" onClick="registration()" >Register</button>
                        <div class="options">
                           <a href="index.php">Home</a>
               
                            
                        </div>
                    </div>

                </form>     
            </div>
        </div>
    </div>
</body>
</html>