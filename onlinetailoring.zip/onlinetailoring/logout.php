<?php
if(isset($_GET['logout'])) {
    session_start();
    session_destroy();
    unset($_SESSION['username']);
    unset($_SESSion["password"]);

    header('location:login.php');
    exit;
    
}
?>