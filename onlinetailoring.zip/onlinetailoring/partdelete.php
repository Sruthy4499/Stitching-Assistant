<?php
include 'connection.php';
if(isset($_GET['part_id']))
{
    $id=$_GET['part_id'];
    $sql = "DELETE FROM part WHERE part_id=$id";
    $result = mysqli_query($con, $sql);
    if($result)
    {
      header('location:measurment_parts.php');
    }
    else{
        echo "no!";
    }
    }

?>