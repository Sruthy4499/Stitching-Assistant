
<!-- <?php

session_start();

?> -->
<html>

<center>

	<head>
		<title>Sign up</title>

		<link rel="stylesheet" type="text/css" href="style.css" />
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>

		<script type="text/javascript">
		$(document).ready(function() {
			$("form").submit(function() {

				var validation = $(this); // Select Form
				//var log_type = $("#type");


				if (validation.find("[name='style_name']").val() == '') {
					alert('Enter Style Name');
					return false;
                    }
                    if (validation.find("[name='style_choose']").val() == '') {
					alert('choose button');
					return false;
                    }
				alert('You insert sucessfully');

				$("#myform")[1].reset();
			});
		});
		</script>


	</head>
	<script>
	function pageRedirect() {
		window.location.href = "measurment.php";
	}
	</script>

	<body>
		<div class="bg">



			<br>
			<div class="container">
				
				<div class="logo">
					<a href="measurment.php"><img src="vismaya.png"></a>
				</div>
				<div class="con1">
				<div class="logi">Choose Here!</div>
				<br>

				<form id="myform" name="form" method="POST" action="style.php"
					onsubmit="return validation(this);">
					<div class="act">
						<br>
						<div class="user">
							<input class="input" type=text name=style_name id=name placeholder="Name">
							<br> <br>
						

							<input class="radio" type=radio name=style_choose value="YES" checked><label
								class="label">YES</label>
							<input class="radio" type=radio name=style_choose value="NO"><label
								class="label">NO</label>
						</div>

						<div class="select">
							<select id=type name=log_type>
								<option value="">
									<div class="text">Who am I</div>
								</option>

								<option value=0>
									<div class="text">User</div>
								</option>
								<option value=1>
									<div class="text">Evaluator</div>
								</option>
							</select>
						</div>
						






						<div class="new">
							<table>
								<tr>
									
									<td>

										<div class="continue">
											<input class="input" id="submit" type=submit name=submit
												value=Continue>
										</div>

									</td>
									<td>
										<div class="cancel">
											<input class="input" type=button value=Cancel
												onclick="pageRedirect()">


										</div>
									</td>
								</tr>
							</table>




						</div>


					</div>


				</form>
			</div>
		</div>
		</div>

</center>

<?php
	include 'footer.php';

	?>
</div>

</body>

</html>





<!-- <?php
session_start();
ob_start();
 //$id=$_SESSION['id']; -->
  require 'connect.php';
$usrname = $_POST['reg_name'];  
$usrmail = $_POST['log_email']; //store in login_table
$usrgender = $_POST['reg_gender'];
$usrdob = $_POST['reg_dob'];
$usrpassword = $_POST['log_password']; //store in login_table
$usrphone = $_POST['reg_phone'];
$usrtype = $_POST['log_type'];//store in login_table
$district = $_POST['district'];
//$sqll=;
$result= mysqli_query($con,"SELECT * FROM register WHERE log_email='$usrmail'");
$count = mysqli_num_rows($result);
//echo $count;
//echo "error".$sqll."<br>".$con->error;

if($count>0)
{
	//echo $count;
	header('location:login.php?show=User already exits');
	exit();
	//echo "error".$sql."<br>".$con->error;

} 
else
{
//$sql=;
//$sql1="INSERT INTO login (log_email,log_password,log_type)VALUES('$usrmail','$usrpassword','$usrtype')";   
if(mysqli_query($con,"INSERT INTO register (reg_name,log_email,reg_gender,reg_dob,log_password,reg_phone,log_type,district)VALUES ('$usrname', '$usrmail','$usrgender', '$usrdob','$usrpassword','$usrphone','$usrtype','$district')"))
{     
	//echo "error".$sql."<br>".$con->error;  
	       
header('location:login.php?show=added sucessfully');
}  
else
{
	echo "error".$sql."<br>".$con->error;
}    
}	
//echo "error".$sql."<br>".$con->error;

		   			
?>